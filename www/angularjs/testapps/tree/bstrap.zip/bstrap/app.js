var app = angular.module("strapTree", [
    'ep-components',
    'ui.bootstrap'
]) ;

app.   controller("mainCtrl", function ($scope,$timeout) {
        $scope.treeOpts = {
            treeDefs:{nodeName:"label}",leafName:"children.label",leafTemplate:''},
            data:[{
                           label: 'Root', children: [
                               {
                                   label: "This Folder is Closed By Default", children: [
                                   {label: "Can You Believe...",
                                       template:'<span>This is just text&nbsp;<i class="fa fa-trash-o fa-lg"></i>&nbsp;<input type="text" ng-model="treeText"/>AAAA</span>',
                                       //templateUrl:"view-template.html"
                                   },
                                   {label: "One Deep",children:[{label:"First"},{label:"Second"}]}
                               ], expanded: true
                               },
                               {label: "This One is Open by Default...", expanded: true},
                               {label: "Can You Believe...",disabled:true}]
                       }],

        width:500,
        height:200,
/*
        icons:{
            openedClass:'fa fa-folder-open fa-2x',
            closedClass:'fa fa-folder fa-2x',
            leafClass:'fa fa-file-o fa-2x'
        }
*/
        };


    $scope.treeText = "test";

    $timeout(function(){
    $scope.treeOpts.expandAll();
    $timeout(function(){
        $scope.treeOpts.disable('tree-1_tree-item-3');
        $timeout(function(){
            $scope.treeOpts.enable('tree-1_tree-item-3');
        },1000);

    },1000);
    },1);
    });